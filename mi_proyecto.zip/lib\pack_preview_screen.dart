import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'mock_data.dart';
import 'favorites_repository.dart';
import 'page_transitions.dart';
import 'profile_screen.dart';
import 'auth_service.dart';
import 'firestore_service.dart';
import 'supabase_storage_service.dart';

/// Vista pública de un pack: solo para ver los stickers y "descargarlo"
/// (añadirlo a WhatsApp). Sin ningún acceso de edición.
///
/// Puede mostrar un pack REAL (identifier real, se puede añadir a
/// WhatsApp de verdad) o un pack MOCK (de un creador simulado — el botón
/// de descargar muestra un aviso de que es una demo, ya que ese pack no
/// existe realmente en el dispositivo).
class PackPreviewScreen extends StatefulWidget {
  final String? realIdentifier;
  final MockPack? mockPack;
  final String packName;
  final String? publisherName;
  final String? publisherId;
  final int stickerCount;
  final bool isPrivate;

  const PackPreviewScreen({
    super.key,
    this.realIdentifier,
    this.mockPack,
    required this.packName,
    this.publisherName,
    this.publisherId,
    required this.stickerCount,
    this.isPrivate = false,
  });

  @override
  State<PackPreviewScreen> createState() => _PackPreviewScreenState();
}

class _PackPreviewScreenState extends State<PackPreviewScreen> {
  static const _channel = MethodChannel('whatsapp_stickers_channel');
  List<Uint8List> _stickers = [];
  bool _loading = true;
  bool _isSaving = false;
  final _favoritesRepo = FavoritesRepository();

  // Servicios
  final _auth = AuthService.instance;
  final _firestore = FirestoreService.instance;
  final _storage = SupabaseStorageService.instance;

  bool get _isMock => widget.realIdentifier == null;
  bool get _isOwner => widget.publisherId == currentUserId;

  @override
  void initState() {
    super.initState();
    if (!_isMock) {
      _loadRealStickers();
    } else {
      _loading = false;
    }
  }

  Future<void> _loadRealStickers() async {
    try {
      final stickers = await _channel
          .invokeListMethod<Uint8List>('getStickersForPack', {'identifier': widget.realIdentifier});
      if (mounted) setState(() => _stickers = stickers ?? []);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _download() async {
    if (_isMock) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Esto es una demo — con el backend real, aquí se añadiría el pack a tu WhatsApp.'),
        ),
      );
      return;
    }
    try {
      final result = await _channel.invokeMethod<String>('addStickerPack', {
        'identifier': widget.realIdentifier!,
        'name': widget.packName,
      });
      final mensaje = switch (result) {
        'added' => 'Pack añadido ✅',
        'cancelled' => 'Cancelado',
        _ => 'Resultado: $result',
      };
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mensaje)));
    } on PlatformException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: ${e.message}')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final mock = widget.mockPack;

    return DefaultTabController(
      length: 1,
      child: Scaffold(
        floatingActionButtonLocation: _isOwner ? null : FloatingActionButtonLocation.centerFloat,
        floatingActionButton: ElevatedButton.icon(
          onPressed: _download,
          icon: const Icon(Icons.add_circle_outline_rounded, size: 20),
          label: const Text('Añadir a WhatsApp'),
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: const StadiumBorder(),
          ),
        ),
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              title: Text(widget.packName),
              pinned: true,
            ),
            SliverToBoxAdapter(
              child: _buildHeader(context),
            ),
            if (_loading)
              const SliverFillRemaining(child: Center(child: CircularProgressIndicator()))
            else if (_isMock)
              _MockStickerGrid(mock: mock!)
            else if (_stickers.isEmpty)
              const SliverFillRemaining(child: Center(child: Text('Este pack no tiene stickers')))
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), // Padding for FAB
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (context, index) => _StickerGridTile(stickerBytes: _stickers[index]),
                    childCount: _stickers.length,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.packName,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          if (widget.publisherName != null && widget.publisherName!.isNotEmpty) ...[
            const SizedBox(height: 4),
            GestureDetector(
              onTap: widget.publisherId != null
                  ? () {
                      Navigator.push(
                        context,
                        slideUpRoute(ProfileScreen(profileId: widget.publisherId!)),
                      );
                    }
                  : null,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('de ${widget.publisherName!}', style: Theme.of(context).textTheme.titleMedium),
                  if (widget.publisherId != null) ...[
                    const SizedBox(width: 4),
                    Icon(Icons.chevron_right, size: 18, color: Colors.grey.shade700),
                  ]
                ],
              ),
            )
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              _StatItem(value: '${widget.stickerCount}', label: 'stickers'),
              const SizedBox(width: 16),
              _StatItem(value: '—', label: 'descargas'), // Placeholder
              const SizedBox(width: 16),
              _StatItem(value: '—', label: 'vistas'), // Placeholder
            ],
          ),
        ],
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String value;
  final String label;

  const _StatItem({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 13)),
      ],
    );
  }
}

class _StickerGridTile extends StatelessWidget {
  final Uint8List stickerBytes;

  const _StickerGridTile({required this.stickerBytes});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Image.memory(stickerBytes, fit: BoxFit.contain),
    );
  }
}

class _MockStickerGrid extends StatelessWidget {
  final MockPack mock;
  const _MockStickerGrid({required this.mock});

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
      sliver: SliverGrid.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemCount: mock.stickerCount,
        itemBuilder: (context, index) => Container(
          decoration: BoxDecoration(
            color: Colors.grey.shade200,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(mock.previewIcon, color: mock.previewColor, size: 40),
        ),
      ),
    );
  }
}
