import 'dart:typed_data';
import 'package:flutter/material.dart';

/// Grid de preview para los stickers en la tarjeta del pack.
class StickerPreviewGrid extends StatelessWidget {
  final List<Uint8List>? previewStickers;
  final List<String>? previewStickerUrls;

  const StickerPreviewGrid({super.key, this.previewStickers, this.previewStickerUrls});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Builder(
      builder: (context) {
        final hasLocalStickers = previewStickers != null && previewStickers!.isNotEmpty;
        final hasRemoteStickers = previewStickerUrls != null && previewStickerUrls!.isNotEmpty;

        if (!hasLocalStickers && !hasRemoteStickers) {
          return Center(child: Icon(Icons.image_rounded, size: 48, color: colorScheme.primary.withOpacity(0.35)));
        }

        // Estilo de cuadrícula minimalista
        final itemCount = hasLocalStickers ? previewStickers!.take(4).length : previewStickerUrls!.take(4).length;

        return GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 6,
            mainAxisSpacing: 6,
          ),
          itemCount: itemCount,
          itemBuilder: (context, index) {
            final image = hasLocalStickers
                ? Image.memory(previewStickers![index], fit: BoxFit.contain)
                : Image.network(
                    previewStickerUrls![index],
                    fit: BoxFit.contain,
                    loadingBuilder: (context, child, progress) {
                      if (progress == null) return child;
                      return Center(
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          value: progress.expectedTotalBytes != null
                              ? progress.cumulativeBytesLoaded / progress.expectedTotalBytes!
                              : null,
                        ),
                      );
                    },
                  );
            return ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: image,
            );
          },
        );
      },
    );
  }
}