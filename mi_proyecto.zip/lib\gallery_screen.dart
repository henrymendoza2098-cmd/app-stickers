import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'create_pack_screen.dart';


class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  State<GalleryScreen> createState() => GalleryScreenState();
}

class GalleryScreenState extends State<GalleryScreen> {
  static const _channel = MethodChannel('whatsapp_stickers_channel');
  List<Map<String, dynamic>> _packs = [];
  final Map<String, Uint8List> _trayCache = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    loadPacks();
  }

  Future<void> loadPacks() async {
    setState(() => _loading = true);
    try {
      final jsonStr = await _channel.invokeMethod<String>('getStickerPacks');
      final List<dynamic> list = jsonDecode(jsonStr ?? '[]');
      _packs = list.cast<Map<String, dynamic>>();

      for (final pack in _packs) {
        final id = pack['identifier'] as String;
        if (!_trayCache.containsKey(id)) {
          final bytes = await _channel.invokeMethod<Uint8List>('getPackTray', {'identifier': id});
          if (bytes != null) _trayCache[id] = bytes;
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Error cargando packs: $e')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _addToWhatsApp(String identifier, String name) async {
    try {
      final result = await _channel.invokeMethod<String>('addStickerPack', {
        'identifier': identifier,
        'name': name,
      });
      final mensaje = switch (result) {
        'added' => 'Pack añadido ✅',
        'cancelled' => 'Cancelado',
        _ => 'Resultado: $result',
      };
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mensaje)));
      }
    } on PlatformException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Error: ${e.message}')));
      }
    }
  }

  Future<void> _deletePack(String identifier) async {
    await _channel.invokeMethod('deleteStickerPack', {'identifier': identifier});
    _trayCache.remove(identifier);
    loadPacks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mis packs de stickers')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _packs.isEmpty
              ? const Center(
                  child: Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Text('Todavía no tienes packs. Crea el primero con el botón +', textAlign: TextAlign.center),
                ))
              : RefreshIndicator(
                  onRefresh: loadPacks,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(8),
                    itemCount: _packs.length,
                    itemBuilder: (context, index) {
                      final pack = _packs[index];
                      final identifier = pack['identifier'] as String;
                      final name = pack['name'] as String;
                      final publisher = pack['publisher'] as String;
                      final isDynamic = pack['isDynamic'] as bool? ?? false;
                      final trayBytes = _trayCache[identifier];

                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        child: InkWell(
                          onTap: () {
                            if (isDynamic) {
                              Navigator.push<bool>(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => CreatePackScreen(
                                    packName: name,
                                    publisher: publisher,
                                    identifier: identifier,
                                    isEditing: true,
                                  ),
                                ),
                              ).then((updated) {
                                if (updated == true) loadPacks();
                              });
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(12.0),
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 64,
                                  height: 64,
                                  child: trayBytes != null
                                      ? Image.memory(trayBytes, fit: BoxFit.contain)
                                      : const Icon(Icons.image, size: 40, color: Colors.grey),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                                      Text(publisher, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                                      Text('${pack['stickerCount']} stickers', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.send_to_mobile),
                                  tooltip: 'Añadir a WhatsApp',
                                  onPressed: () => _addToWhatsApp(identifier, name),
                                ),
                                if (isDynamic)
                                  IconButton(
                                    icon: const Icon(Icons.delete_outline),
                                    tooltip: 'Eliminar',
                                    onPressed: () => _deletePack(identifier),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showCreatePackSheet,
        icon: const Icon(Icons.add),
        label: const Text('Nuevo pack'),
      ),
    );
  }
  void _showCreatePackSheet() {
    final nameController = TextEditingController();
    final publisherController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
          left: 16,
          right: 16,
          top: 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Nuevo pack de stickers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Nombre del pack')),
            const SizedBox(height: 8),
            TextField(controller: publisherController, decoration: const InputDecoration(labelText: 'Autor')),
            const SizedBox(height: 16),
            ElevatedButton(
              child: const Text('Crear y añadir stickers'),
              onPressed: () {
                Navigator.pop(context); // Cierra el bottom sheet
                Navigator.push<bool>(
                  context,
                  MaterialPageRoute(builder: (_) => CreatePackScreen(packName: nameController.text, publisher: publisherController.text)),
                ).then((created) => { if (created == true) loadPacks() });
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
