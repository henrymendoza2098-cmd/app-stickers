import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'crop_screen.dart';

class CreatePackScreen extends StatefulWidget {
  final String? packName;
  final String? publisher;
  final String? identifier;
  final bool isEditing;
  final List<Uint8List>? initialStickers;

  const CreatePackScreen({
    super.key,
    this.packName,
    this.publisher,
    this.identifier,
    this.isEditing = false,
    this.initialStickers,
  });

  @override
  State<CreatePackScreen> createState() => _CreatePackScreenState();
}

class _CreatePackScreenState extends State<CreatePackScreen> {
  static const _channel = MethodChannel('whatsapp_stickers_channel');
  final _nameController = TextEditingController();
  final _publisherController = TextEditingController();
  final List<Uint8List> _stickers = [];
  bool _saving = false;
  String _status = '';
  bool _loadingStickers = false;

  @override
  void initState() {
    super.initState();
    if (widget.packName != null) _nameController.text = widget.packName!;
    if (widget.publisher != null) _publisherController.text = widget.publisher!;
    if (widget.initialStickers != null) _stickers.addAll(widget.initialStickers!);
    if (widget.isEditing) _loadExistingStickers();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _publisherController.dispose();
    super.dispose();
  }

  Future<void> _addSticker() async {
    final Uint8List? original = await _channel.invokeMethod<Uint8List>('pickImage');
    if (original == null || !mounted) return;

    final cropped = await Navigator.push<Uint8List>(
      context,
      MaterialPageRoute(builder: (_) => CropScreen(imageBytes: original)),
    );
    if (cropped == null) return;

    setState(() => _stickers.add(cropped));
  }

  void _removeSticker(int index) {
    setState(() => _stickers.removeAt(index));
  }

  Future<void> _savePack() async {
    final name = _nameController.text.trim(); // publisher se usa desde el widget
    if (name.isEmpty) {
      setState(() => _status = 'Ponle un nombre al pack');
      return;
    }
    if (_stickers.length < 3) {
      setState(() => _status = 'Necesitas al menos 3 stickers (tienes ${_stickers.length})');
      return;
    }

    setState(() {
      _saving = true;
      _status = '';
    });

    final identifier = widget.identifier ?? 'pack_${DateTime.now().millisecondsSinceEpoch}';

    try {
      await _channel.invokeMethod('saveStickerPack', {
        'identifier': identifier,
        'name': name,
        'publisher': widget.publisher ?? _publisherController.text.trim(),
        'tray': _stickers.first, // el primer sticker se usa como ícono de bandeja
        'stickers': _stickers
            .map((bytes) => {
                  'bytes': bytes,
                  'emojis': ['😀'],
                })
            .toList(),
      });
      if (mounted) Navigator.pop(context, true);
    } on PlatformException catch (e) {
      setState(() => _status = 'Error al guardar: ${e.message}');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _loadExistingStickers() async {
    if (widget.identifier == null) return;
    setState(() => _loadingStickers = true);
    try {
      final List<Uint8List>? stickerBytes =
          await _channel.invokeListMethod<Uint8List>('getStickersForPack', {'identifier': widget.identifier});
      if (stickerBytes != null && mounted) {
        setState(() {
          _stickers.addAll(stickerBytes);
        });
      }
    } on PlatformException catch (e) {
      setState(() => _status = 'Error cargando stickers: ${e.message}');
    } finally {
      if (mounted) setState(() => _loadingStickers = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.isEditing ? 'Editar pack' : 'Crear nuevo pack')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Si estamos creando un pack nuevo desde el botón de la galería (sin datos previos)
            if (widget.packName == null) ...[
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Nombre del pack',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                  controller: _publisherController,
                  decoration: const InputDecoration(
                    labelText: 'Autor del pack',
                    border: OutlineInputBorder(),
                  )),
              const SizedBox(height: 16),
            ] else ...[
              // Si ya tenemos nombre (viniendo del bottom sheet o editando)
              Text('Pack: ${widget.packName}', style: Theme.of(context).textTheme.titleLarge),
              if (widget.publisher != null && widget.publisher!.isNotEmpty)
                Text(
                  'Autor: ${widget.publisher}',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
              const SizedBox(height: 16),
            ],
            Text('Stickers (${_stickers.length}/30, mínimo 3)'),
            const SizedBox(height: 8),
            Expanded(
              child: _loadingStickers
                  ? const Center(child: CircularProgressIndicator())
                  : GridView.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: _stickers.length + (_stickers.length < 30 ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index == _stickers.length) {
                    return InkWell(
                      onTap: _addSticker,
                      child: Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.add_photo_alternate, size: 32),
                      ),
                    );
                  }
                  return Stack(
                    children: [
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.memory(_stickers[index], fit: BoxFit.cover),
                        ),
                      ),
                      Positioned(
                        top: 2,
                        right: 2,
                        child: GestureDetector(
                          onTap: () => _removeSticker(index),
                          child: const CircleAvatar(
                            radius: 12,
                            backgroundColor: Colors.black54,
                            child: Icon(Icons.close, size: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
            if (_status.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(_status, style: const TextStyle(color: Colors.red)),
              ),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saving ? null : _savePack,
                child: _saving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Guardar pack'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
