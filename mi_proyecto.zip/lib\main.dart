import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'gallery_screen.dart';
import 'create_pack_screen.dart';
import 'crop_screen.dart';

void main() {
  runApp(const MyApp());
}

final GlobalKey<_MainScreenState> mainScreenKey = GlobalKey();
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mis Stickers',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MainScreen(key: mainScreenKey),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  static const _channel = MethodChannel('whatsapp_stickers_channel');
  final GlobalKey<GalleryScreenState> _galleryKey = GlobalKey<GalleryScreenState>();

  void refreshGallery() {
    _galleryKey.currentState?.loadPacks();
  }
  int _selectedIndex = 0;

  late final List<Widget> _widgetOptions;

  @override
  void initState() {
    super.initState();
    _widgetOptions = <Widget>[
      GalleryScreen(key: _galleryKey),
      const Center(child: Text('Aquí irá tu perfil de usuario.')),
    ];
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _widgetOptions.elementAt(_selectedIndex),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            IconButton(
              icon: const Icon(Icons.home),
              color: _selectedIndex == 0 ? Theme.of(context).primaryColor : Colors.grey,
              onPressed: () => _onItemTapped(0),
            ),
            IconButton(
              icon: const Icon(Icons.add_circle_outline, size: 32),
              onPressed: _onAddStickerTapped,
            ),
            IconButton(
              icon: const Icon(Icons.person),
              color: _selectedIndex == 1 ? Theme.of(context).primaryColor : Colors.grey,
              onPressed: () => _onItemTapped(1),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _onAddStickerTapped() async {
    // 1. Abrir galería y seleccionar imagen
    final Uint8List? original = await _channel.invokeMethod<Uint8List>('pickImage');
    if (original == null || !mounted) return;

    // 2. Abrir pantalla de recorte
    final cropped = await Navigator.push<Uint8List>(
      context,
      MaterialPageRoute(builder: (_) => CropScreen(imageBytes: original)),
    );
    if (cropped == null || !mounted) return;

    // 3. Mostrar panel inferior para elegir pack
    _showSaveStickerSheet(cropped);
  }

  void _showSaveStickerSheet(Uint8List newSticker) {
    showModalBottomSheet(
      context: context,
      builder: (context) => _SaveStickerSheet(
        newSticker: newSticker,
        channel: _channel,
        onStickerSaved: () {
          refreshGallery();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('¡Sticker guardado con éxito! ✅')),
          );
        },
      ),
    );
  }
}

/// Widget para el panel inferior que permite guardar un sticker
class _SaveStickerSheet extends StatefulWidget {
  final Uint8List newSticker;
  final MethodChannel channel;
  final VoidCallback onStickerSaved;

  const _SaveStickerSheet({required this.newSticker, required this.channel, required this.onStickerSaved});

  @override
  State<_SaveStickerSheet> createState() => _SaveStickerSheetState();
}

class _SaveStickerSheetState extends State<_SaveStickerSheet> {
  List<Map<String, dynamic>> _packs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadUserPacks();
  }

  Future<void> _loadUserPacks() async {
    setState(() => _loading = true);
    final jsonStr = await widget.channel.invokeMethod<String>('getStickerPacks');
    final List<dynamic> allPacks = jsonDecode(jsonStr ?? '[]');
    if (mounted) {
      setState(() {
        _packs = allPacks.cast<Map<String, dynamic>>().where((p) => p['isDynamic'] == true).toList();
        _loading = false;
      });
    }
  }

  Future<void> _addStickerToPack(String identifier) async {
    try {
      await widget.channel.invokeMethod('addStickerToPack', {
        'identifier': identifier,
        'stickerBytes': widget.newSticker,
        'emojis': ['😀'], // Emojis por defecto
      });
      if (mounted) {
        Navigator.pop(context); // Cierra el bottom sheet
        widget.onStickerSaved();
      }
    } catch (e) {
      // Manejar error
    }
  }

  void _createNewPack() {
    Navigator.pop(context); // Cerrar el sheet
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CreatePackScreen(initialStickers: [widget.newSticker]),
      ),
    ).then((saved) {
      if (saved == true) widget.onStickerSaved();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Guardar sticker en...', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          ListTile(
            leading: const Icon(Icons.add_circle_outline),
            title: const Text('Crear nuevo pack'),
            onTap: _createNewPack,
          ),
          const Divider(),
          if (_loading)
            const Center(child: CircularProgressIndicator())
          else
            Expanded(
              child: ListView.builder(
                itemCount: _packs.length,
                itemBuilder: (context, index) {
                  final pack = _packs[index];
                  return ListTile(
                    leading: const Icon(Icons.collections_bookmark_outlined),
                    title: Text(pack['name']),
                    subtitle: Text(pack['publisher']),
                    onTap: () => _addStickerToPack(pack['identifier']),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
